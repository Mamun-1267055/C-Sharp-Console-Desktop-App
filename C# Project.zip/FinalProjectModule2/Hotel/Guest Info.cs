﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProjectModule2.Hotel
{
    public class Guest_Info
    {
        public int Guestid { get; set; }
        public string Guestname { get; set; }
        public int Guestnumber { get; set; }
        public string Gender { get; set; }
        public string RoomType { get; set; }
        public int Stayingdays { get; set; }
        public DateTime Bookingdate { get; set; }
    }
}
